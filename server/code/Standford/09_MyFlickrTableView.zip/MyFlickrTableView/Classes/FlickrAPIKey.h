// If you want to build and run this yourself, register for a free Flickr API key and enter it below.
#warning Type your Flickr API key here and then delete this line!
NSString *const FlickrAPIKey = @"TYPE_YOUR_FLICKR_API_KEY_HERE";
